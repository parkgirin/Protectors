using System;

public enum PropertyType
{
    Int,
    Float,
    Bool,
    String
}

[Serializable]
public class AttackProperty
{
    public string key;           // ��: damage, cooldown, pierceCount
    public PropertyType type;

    // ���� �� (Ÿ�Ժ� �ϳ��� ���)
    public int intValue;
    public float floatValue;
    public bool boolValue;
    public string stringValue;

    public object GetValue()
    {
        return type switch
        {
            PropertyType.Int => intValue,
            PropertyType.Float => floatValue,
            PropertyType.Bool => boolValue,
            PropertyType.String => stringValue,
            _ => null
        };
    }
}
