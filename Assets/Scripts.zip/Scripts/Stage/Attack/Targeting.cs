using UnityEngine;

public class Targeting : MonoBehaviour
{
    public float checkInterval = 0.5f;
    private float timer = 0f;

    public GameObject CurrentTarget;

    public GameObject targetMarker;
    public GameObject targetPrefab;

    // �պ� �̵��� ����
    public float moveRange = 2f;   // �պ� ����
    public float moveSpeed = 2f;   // �̵� �ӵ�
    private Vector3 startPos;

    private void OnEnable()
    {
        if (targetPrefab != null)
        {
            targetMarker = Instantiate(targetPrefab);
            targetMarker.SetActive(false);
        }

        startPos = new Vector3(0, 0, 0);
    }

    private void Update()
    {
        timer += Time.deltaTime;
        if (timer >= checkInterval)
        {
            UpdateTarget();
            timer = 0f;
        }

        // Ÿ���� ���ٸ� �ӽ� �պ� �̵� �Լ�
        if (CurrentTarget == null) Move();
    }

    void Move()
    {
        // �պ� �̵�
        if (targetMarker.activeSelf)
        {
            float x = Mathf.PingPong(Time.time * moveSpeed, moveRange * 2) - moveRange;
            targetMarker.transform.position = startPos + new Vector3(x, 0f, 0f);
        }
    }
    void UpdateTarget()
    {
        CurrentTarget = EnemyManager.Instance.GetClosestEnemy(transform.position, StageManager.Instance.context.attackRange);

        // ���� Ÿ���� ���� ��� �ӽ÷� ��Ŀ ���̰Ը� ó��
        if (CurrentTarget != null)
        {
            targetMarker.SetActive(true);
            targetMarker.transform.position = CurrentTarget.transform.position;
        }
        else
        {
            // �ӽ� �׽�Ʈ������ Ÿ���� ��� Ȱ��ȭ
            targetMarker.SetActive(true);
        }
    }
}
