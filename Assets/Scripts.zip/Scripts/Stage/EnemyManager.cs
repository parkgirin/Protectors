using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyManager : MonoBehaviour
{
    public static EnemyManager Instance;

    public List<GameObject> enemyPrefab = new List<GameObject>(); // ������ �� ������
    public int maxEnemies = 150;   // ��ü Ǯ ��
    public int maxActiveEnemies = 100; // ȭ�� �� �ִ� Ȱ�� �� ��

    public List<GameObject> activeEnemies = new List<GameObject>();
    public Queue<GameObject> pendingEnemies = new Queue<GameObject>(); // ������� ��

    // Ǯ���� ����Ʈ
    public List<GameObject> enemyPool = new List<GameObject>();

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            Debug.Log("[EnemyManager] Instance ��� �Ϸ�");
        }

        InitializePool();
    }

    private void Update()
    {
        // ��� �� Ȱ��ȭ
        if (pendingEnemies.Count > 0 && activeEnemies.Count < maxActiveEnemies)
        {
            //Debug.Log($"[OnEnemyDestroyed] ��� �� Ȱ��ȭ, ���� �� {pendingEnemies.Count - 1}");
            GameObject next = pendingEnemies.Dequeue();
            ActivateEnemy(next);
        }
    }

    void InitializePool()
    {
        for (int i = 0; i < maxEnemies; i++)
        {
            // EnemyManager�� �ڽ����� ����
            if(enemyPrefab.Count > 1)
            {
                int randomIndex = Random.Range(0, enemyPrefab.Count);
                GameObject enemy = Instantiate(enemyPrefab[randomIndex], this.transform);
                enemy.SetActive(false);
                enemyPool.Add(enemy);

            }
            else
            {
                GameObject enemy = Instantiate(enemyPrefab[0], this.transform);
                enemy.SetActive(false);
                enemyPool.Add(enemy);
            }
        }
    }

    // --------------------------------
    // SpawnEnemies: Ǯ���� �� ������ Ȱ��ȭ / ��⿭ ����
    // --------------------------------
    public void SpawnEnemies(int count)
    {
        for (int i = 0; i < count; i++)
        {
            GameObject enemy = GetNextEnemyFromPool();
            if (enemy == null)
            {
                Debug.LogWarning("[SpawnEnemies] Ǯ�� ���� Enemy ����!");
                break;
            }

            if (activeEnemies.Count < maxActiveEnemies)
            {
                ActivateEnemy(enemy);
            }
            else
            {
                pendingEnemies.Enqueue(enemy);
            }
        }
    }

    public void ActivateEnemy(GameObject enemy)
    {
        //Debug.Log("[ActivateEnemy] �� Ȱ��ȭ");
        enemy.SetActive(true);
        enemy.transform.parent = this.transform; // �����ϰ� �θ� ����
        RegisterEnemy(enemy);
    }

    GameObject GetNextEnemyFromPool()
    {
        foreach (var enemy in enemyPool)
        {
            if (!enemy.activeSelf)
                return enemy;
        }
        Debug.LogWarning("[GetNextEnemyFromPool] Ǯ�� ���� Enemy ����!");
        return null;
    }

    public void RegisterEnemy(GameObject enemy)
    {
        if (!activeEnemies.Contains(enemy))
            activeEnemies.Add(enemy);
    }

    public void UnregisterEnemy(GameObject enemy)
    {
        if (activeEnemies.Contains(enemy))
            activeEnemies.Remove(enemy);
    }

    // --------------------------------
    // �� ���� �� ��⿭ ó��
    // --------------------------------
    public void OnEnemyDestroyed(GameObject enemy)
    {
        UnregisterEnemy(enemy);

        // ���� �� ��Ȱ��ȭ
        enemy.SetActive(false);
    }

    public GameObject GetClosestEnemy(Vector3 fromPosition, float maxTargetDistance)
    {
        GameObject closestEnemy = null;
        float closestDistanceSqr = Mathf.Infinity;

        // Ȱ��ȭ�� ���鸸 �˻�
        foreach (var enemy in activeEnemies)
        {
            if (enemy == null || !enemy.activeSelf) continue;

            float sqrDistance = (enemy.transform.position - fromPosition/2).sqrMagnitude;

            // �Ÿ� ���� ����
            if (sqrDistance > maxTargetDistance * maxTargetDistance)
                continue;

            if (sqrDistance < closestDistanceSqr)
            {
                closestDistanceSqr = sqrDistance;
                closestEnemy = enemy;
            }
        }

        return closestEnemy; // ������ null ��ȯ
    }
}
