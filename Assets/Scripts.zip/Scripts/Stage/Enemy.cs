using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public int HP_Set = 10;
    public float hp;
    public TextMeshPro TMPro_hp;
    public float speed = 1f;
    public bool attacking = false;
    public float attackDelay = 1f;

    private StageManager stageManager;
    public GameObject dieAnime;

    private void OnEnable()
    {
        // ������ �� �̸� ã�Ƶ� (Inspector ��� �ڵ�� ����)
        stageManager = FindObjectOfType<StageManager>();
        if (stageManager == null)
            Debug.LogWarning("StageManager�� ã�� �� �����ϴ�. �������� ���� ����� �������� ���� �� �ֽ��ϴ�.");
        hp = HP_Set;
        TMPro_hp.text = hp.ToString();

        // �ʱ� ��ġ ����
        float x = Random.Range(-2.3f, 2.3f);
        this.transform.position = new Vector3(x, 4f, 0);

        float randomFactor = Random.Range(0.8f, 1.2f);
        speed *= randomFactor;
        attacking = false;
    }

    void Update()
    {
        if (hp <= 0)
        {
            DieAnime();
        }
        else if (!attacking)
        {
            transform.Translate(Vector2.down * speed * Time.deltaTime);
        }
        else
        {
            // �ð� ���� �� ���� ����
            attackDelay -= Time.deltaTime;
            if (attackDelay <= 0f)
            {
                Attack();
                attackDelay = 1f; // ���� �� ������ �ʱ�ȭ
            }
        }
    }

    public void Die()
    {
        if (StageManager.Instance != null)
            StageManager.Instance.OnEnemyDefeated();

        if (EnemyManager.Instance != null)
        {
            EnemyManager.Instance.UnregisterEnemy(gameObject);
            EnemyManager.Instance.OnEnemyDestroyed(gameObject);
        }
    }
    public void DieAnime()
    {
        if (dieAnime != null)
        {
            GameObject anime = Instantiate(dieAnime);
            anime.transform.position = this.transform.position;
        }
        else
        {
            Debug.LogWarning("Die Anime Prefab is not assigned.");
        }
        Die();
    }

    public void TakeDamage(float damage)
    {
        hp -= damage;
        TMPro_hp.text = hp.ToString();

        if (hp <= 0)
        {
            DieAnime();
        }
    }

    public void Attack()
    {
        stageManager.OnWallHit(1f);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Wall"))
        {
            Debug.Log("Enemy collided with Wall");
            attacking = true;
        }
    }
}
